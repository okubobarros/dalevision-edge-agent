DALE Vision — Edge Agent (Windows)

PASSO A PASSO (2 minutos)
1) Extraia o ZIP em uma pasta (ex.: C:\dalevision-edge-agent\)
2) No Dashboard (Wizard), copie o conteudo do .env
3) Crie um arquivo chamado .env nesta mesma pasta (onde está run.bat) e cole o conteudo
4) Clique duas vezes em run.bat
5) Deixe a janela aberta
6) Volte no Dashboard e aguarde ficar ONLINE

DICAS
- NAO rode de dentro do ZIP. Sempre extraia antes.
- Se aparecer erro de firewall, libere o aplicativo e tente de novo.
- Se der erro de token, gere um novo token no Wizard e copie o .env novamente.
